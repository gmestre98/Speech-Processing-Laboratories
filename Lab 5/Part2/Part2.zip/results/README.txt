We have 2 folders, one for each model.

train0.5 - RNN and Attention/CTC
train1.0 - RNN and CTC

Inside each file
result_decode1.txt - decoded using decode_ctcweight1.0.yaml
result_decode05.txt - decoded using decode_ctcweight0.5.yaml