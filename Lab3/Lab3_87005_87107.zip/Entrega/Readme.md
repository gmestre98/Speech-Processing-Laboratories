# Lab 3 PF <h1>

To run, need to put in the delivered folder the "corpus" folder given and the "opensmile-2.3.0" folder
Predictions are found on folder "predictions", all csvfiles used to train, for development and for the test set are in "csvfiles"

To get the features from the files you need to uncomment the line for the respective feature set on file "getfeatures.sh"
Look lines 25-27

The datasets are not on the delivered folder, since they are too big for the fenix submission, to generate them use the "getfeatures.sh" shell script and they will be generated on the "csvfiles" folder.

The rest is according to what is asked on the lab guide and the report is on the folder
